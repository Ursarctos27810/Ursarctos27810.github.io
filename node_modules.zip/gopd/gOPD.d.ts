export = Object.getOwnPropertyDescriptor;
