declare function RequireObjectCoercible<T extends {}>(value: T, optMessage?: string): T;

export = RequireObjectCoercible;
